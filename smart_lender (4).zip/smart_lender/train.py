import os
import pandas as pd
import joblib

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report

print("Loading dataset...")

# Load dataset
df = pd.read_csv("data/loan_approval_dataset.csv")

# Remove extra spaces from column names
df.columns = df.columns.str.strip()

# Remove extra spaces from text values
for col in df.select_dtypes(include="object").columns:
    df[col] = df[col].str.strip()

# Features and Target
X = df.drop(columns=["loan_id", "loan_status"])
y = df["loan_status"]

# Encode target
y = y.map({"Approved": 0, "Rejected": 1})

# Encode categorical columns
label_encoders = {}

for col in ["education", "self_employed"]:
    le = LabelEncoder()
    X[col] = le.fit_transform(X[col])
    label_encoders[col] = le

# Split data
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42,
    stratify=y
)

# Scale features
scaler = StandardScaler()

X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Models
models = {
    "Logistic Regression": LogisticRegression(max_iter=1000),
    "Random Forest": RandomForestClassifier(random_state=42),
    
}

best_model = None
best_accuracy = 0

for name, model in models.items():
    model.fit(X_train, y_train)
    pred = model.predict(X_test)
    acc = accuracy_score(y_test, pred)

    print(f"{name} Accuracy: {acc*100:.2f}%")

    if acc > best_accuracy:
        best_accuracy = acc
        best_model = model

print("\nBest Accuracy:", best_accuracy * 100)

print("\nClassification Report")
print(classification_report(y_test, best_model.predict(X_test)))

# Save model
os.makedirs("models", exist_ok=True)

joblib.dump(best_model, "models/loan_model.joblib")
joblib.dump(scaler, "models/scaler.joblib")
joblib.dump(label_encoders, "models/label_encoders.joblib")

print("\nTraining completed successfully!")
print("Model saved in models/loan_model.joblib")