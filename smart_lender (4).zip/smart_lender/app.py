import os
import joblib
import numpy as np
from flask import Flask, request, jsonify, render_template

app = Flask(__name__)

# Load model, scaler and encoders
MODEL_PATH = "models/loan_model.joblib"
SCALER_PATH = "models/scaler.joblib"
ENCODER_PATH = "models/label_encoders.joblib"

model = joblib.load(MODEL_PATH)
scaler = joblib.load(SCALER_PATH)
label_encoders = joblib.load(ENCODER_PATH)


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/predict", methods=["POST"])
def predict():
    try:
        no_of_dependents = int(request.form["no_of_dependents"])
        education = request.form["education"]
        self_employed = request.form["self_employed"]
        income_annum = float(request.form["income_annum"])
        loan_amount = float(request.form["loan_amount"])
        loan_term = float(request.form["loan_term"])
        cibil_score = float(request.form["cibil_score"])
        residential_assets_value = float(request.form["residential_assets_value"])
        commercial_assets_value = float(request.form["commercial_assets_value"])
        luxury_assets_value = float(request.form["luxury_assets_value"])
        bank_asset_value = float(request.form["bank_asset_value"])

        education = label_encoders["education"].transform([education])[0]
        self_employed = label_encoders["self_employed"].transform([self_employed])[0]

        features = np.array([[

            no_of_dependents,
            education,
            self_employed,
            income_annum,
            loan_amount,
            loan_term,
            cibil_score,
            residential_assets_value,
            commercial_assets_value,
            luxury_assets_value,
            bank_asset_value

        ]])

        features = scaler.transform(features)

        prediction = model.predict(features)[0]

        if prediction == 0:
            result = "Loan Approved"
        else:
            result = "Loan Rejected"

        return render_template("index.html", prediction_text=result)

    except Exception as e:
        return render_template("index.html", prediction_text=f"Error: {e}")


if __name__ == "__main__":
    app.run(debug=True)