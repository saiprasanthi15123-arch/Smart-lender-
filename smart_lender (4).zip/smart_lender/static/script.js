document.addEventListener("DOMContentLoaded", function () {

    const form = document.querySelector("form");

    form.addEventListener("submit", function (event) {

        const dependents = parseInt(document.querySelector("[name='no_of_dependents']").value);
        const income = parseFloat(document.querySelector("[name='income_annum']").value);
        const loanAmount = parseFloat(document.querySelector("[name='loan_amount']").value);
        const loanTerm = parseFloat(document.querySelector("[name='loan_term']").value);
        const cibil = parseInt(document.querySelector("[name='cibil_score']").value);
        const residential = parseFloat(document.querySelector("[name='residential_assets_value']").value);
        const commercial = parseFloat(document.querySelector("[name='commercial_assets_value']").value);
        const luxury = parseFloat(document.querySelector("[name='luxury_assets_value']").value);
        const bank = parseFloat(document.querySelector("[name='bank_asset_value']").value);

        if (
            dependents < 0 ||
            income <= 0 ||
            loanAmount <= 0 ||
            loanTerm <= 0 ||
            residential < 0 ||
            commercial < 0 ||
            luxury < 0 ||
            bank < 0
        ) {
            alert("Please enter valid positive values.");
            event.preventDefault();
            return;
        }

        if (cibil < 300 || cibil > 900) {
            alert("CIBIL Score must be between 300 and 900.");
            event.preventDefault();
            return;
        }

        alert("Processing your loan application...");
    });

});